.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: Includes.txt


.. _links:

Links
-----

:TER:
	https://typo3.org/extensions/repository/view/<extension key>

:Bug Tracker:
	https://forge.typo3.org/projects/extension-<extension key>/issues

:Git Repository:
	https://github.com/<username>/<extension key>

:Contact:
	`@<username> <https://twitter.com/your-username>`__
