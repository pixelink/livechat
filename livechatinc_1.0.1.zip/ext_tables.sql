#
# Table structure for table 'pages'
#

CREATE TABLE pages (
	exclude_livechat_from_page int(11) DEFAULT '0' NOT NULL
);